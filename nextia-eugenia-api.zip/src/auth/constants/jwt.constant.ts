export const jwtConstants = {
  secret: 'NEAp1',
};
